# Install / use

这些 Skill 主要给本地 AI Coding 工具作为“项目级审核规则”。

可选用法：
1. 将 `skills/<name>` 复制到你的本地 AI 工具支持的 skills 目录；或
2. 不安装，直接让本地 AI 读取对应 `SKILL.md` 后执行；或
3. 把整个 pack 放到 CrossPilot 的 `docs/reference-skills/`，作为代码审核参考，不接生产运行时。

建议先使用：
- crosspilot-code-audit
- crosspilot-action-safety-auditor
- crosspilot-evidence-auditor

不要一上来使用 `crosspilot-stage-gate-designer`，除非真实产品生命周期已经跨多个 Workflow。
