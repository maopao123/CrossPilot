# Upstream skills / repos worth installing separately

> 为避免版本漂移，本包默认不复制第三方仓库代码。需要时安装上游原版。

## 1. kangise/ecommerce-ai-skills
- Repo: https://github.com/kangise/ecommerce-ai-skills
- License: CC0-1.0
- 推荐：`ecom-applicability`、`ecom-research`、`ecom-advertising`、`ecom-compliance`
- 最值得学：boundaries / constraints / playbook 三件套；Ontology；CI Gate。

## 2. zach22-1999/amazon-skills
- Repo: https://github.com/zach22-1999/amazon-skills
- Root license: MIT；`zach-seller-skill-creator` 目录自带 Apache-2.0 LICENSE。
- 推荐：
  - `zach-seller-skill-creator`
  - `zach-product-research`
  - `zach-feature-demand-validator`
- 最值得学：业务 6 问 Gate、with-skill vs baseline、assertions、benchmark、迭代。

## 3. DannylydST/sorftime-seller-agent
- Repo: https://github.com/DannylydST/sorftime-seller-agent
- License: MIT
- 推荐：主 `SKILL.md` 与 closed-loop product selection workflow。
- 最值得学：多平台数据、独立复核、risk advisory、持久化闭环。

## 4. anthropics/commerce-agents
- Repo: https://github.com/anthropics/commerce-agents
- License: Apache-2.0
- 推荐参考：`merchant-agent/skills/`。
- 特别推荐：`pricing-promotions`、`performance-insights`、`inventory-operations`。
- 最值得学：provenance gates、staging、host approval、backend contracts。

## 5. nexscope-ai/eCommerce-Skills
- Repo: https://github.com/nexscope-ai/eCommerce-Skills
- License: MIT
- 推荐：`dynamic-pricing-ecommerce`。
- 安装示例：`npx skills add nexscope-ai/eCommerce-Skills --skill dynamic-pricing-ecommerce -g`
- 最值得学：automation eligibility、rule matrix、simulation、kill switch、shadow/pilot rollout。

## 不建议直接打包
- `JuneYaooo/launchfit-ai`：PolyForm Noncommercial 1.0.0，商业项目只参考思想，不复制代码。
- `zach22-1999/seller-second-brain`：内容许可含 NC，作为方法论参考。
- `nexscope-ai/nexscope-ecommerce-skills`：当前 README 标 proprietary，适合调用其公开服务/按其条款安装，不作为本包复制来源。
