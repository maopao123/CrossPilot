# CrossPilot 外部设计吸收与实施方案

> 版本：2026-09-14  
> 目标：在**不推翻 CrossPilot 已冻结的 Planner / Risk / Action / Adapter / WF-02 / WF-05 主架构**前提下，融合 Starsky、Kimi 代码审核结果，以及一批高价值跨境电商 / Commerce Agent 开源项目的设计经验。

---

## 0. 先给结论

这次不建议把 Starsky 的“6 点”原样变成 6 个新模块，更不建议重写 CrossPilot。

Kimi 对当前代码的审核已经说明：CrossPilot 在 **HITL、Workflow-first、Checkpoint、部分 Evidence Gate** 上并不落后，有些地方甚至比 Starsky 的公开设计更硬。真正需要做的是：

1. **先修现行 P0 破洞**：数据误删、审批绕过、假默认值。
2. **把已有能力收敛成统一 Contract**：Evidence、Risk、Approval、Store Scope。
3. **把已经存在的硬编码 Workflow 收编到 Playbook / UseCaseRouter，而不是引入 LLM 自由 Planner。**
4. **把 Mid-DAG Resume 做实**，让“有 Checkpoint”真正升级为“任务崩了能续跑”。
5. **把 Mock Store 与真实 Adapter 做成同构运行路径**，不要让模拟环境走另一套业务逻辑。
6. **建立 Skill 工程体系**：SOP → Skill/Playbook → Eval → 版本化 → 发布 Gate。
7. Stage Gate、Product/Store Workspace 彻底拆分、Stage Handoff DTO、长期 Decision Memory 都值得做，但应按真实业务复杂度触发，**现在不要为了架构漂亮提前重构**。

最终目标不是复制 Starsky，而是形成：

```text
UseCaseRouter
    ↓
Playbook / Workflow (deterministic happy path)
    ↓
Tool Registry
    ↓
Evidence Contract + Data Quality Gate
    ↓
Recommendation / Action Candidate
    ↓
Risk Policy
    ↓
Approval Proof
    ↓
Action Executor
    ↓
Commerce Adapter
    ↓
Amazon / Shopify / Mock Store / future channels
```

横向能力：

```text
Store / Channel Scope
Checkpoint & Resume
Audit & Provenance
Skill Eval & Release Gate
Decision Memory（后续）
```

---

# 1. CrossPilot 当前代码事实基线（来自 Kimi 审核）

以下内容以本地 AI 已读取 CrossPilot 源码后的审核为事实基线，本方案不擅自推翻这些结论。

| 能力 | 当前实际状态 | 当前判断 |
|---|---|---|
| Stage Gate | 没有独立业务 Stage 模型；已有 Evidence Gate 和 WF-02/WF-05 硬编码 DAG | 暂不重建，未来叠加 |
| Evidence | 四套 evidence 模型并存；Fact → Evidence → Recommendation 已落库；诊断到行动有门禁 | 基础很好，但需收敛和堵洞 |
| HITL | 所有正式写动作要求审批；Amazon Adapter 当前硬只读；payloadHash、过期、OCC、UI 二次确认已存在 | 架构强，但有单点绕过漏洞 |
| Workspace | 当前主要租户级隔离；Product / Store 未彻底拆分 | 真风险不是概念分层，而是 storeId 缺失导致多店串数据 |
| Workflow-first | 已经是 Workflow-first，没有 LLM 自由规划器；WF-02/WF-05 是硬编码 SOP | 方向正确，不要反向引入自由 Planner |
| Checkpoint/Handoff | Checkpoint 基础设施完善；无 Conversation 依赖；缺业务 Handoff，mid-DAG 崩溃续跑不完整 | 先修 Resume，Handoff 后做 |

### 1.1 已经做得好的，明确不要重复建设

- **HITL 是架构强制而非提示词约定**：Amazon 写接口硬限制、Risk → Approval → Action 路径、payloadHash、防过期、防并发覆盖、前端高风险确认都已经存在。
- **Evidence Gate 已真实影响 Action**：INSUFFICIENT 不产出动作，PARTIALLY_SUPPORTED 只允许安全动作，这比“在 Prompt 里说不要幻觉”强得多。
- **Workflow-first 已经成立**：CrossPilot 当前没有 LLM 每次从 0 发明 SOP 的自由 Planner，这一点应继续保持。
- **Checkpoint 基础设施值得复用**：OCC、脱敏、多 backend、原子写，未来 Stage、Resume、Handoff 都应该叠在它上面，而不是另造一套状态系统。

---

# 2. 本次重点研究的外部项目，以及各自只吸收什么

## 2.1 Starsky Amazon Codex

### 吸收
- S1→S5 的业务生命周期意识。
- Stage / Gate / Hold / Handoff 的业务约束思想。
- Evidence First：缺数据就说缺数据，不把缺失当 0。
- 高风险动作停在建议 / 审核 / 导出候选。
- Product 工作与 Store 长期运营属于不同生命周期。

### 不照搬
- 不复制 S1-S5 命名。
- 不把 CrossPilot 从平台架构退化成 Amazon 固定流程产品。
- 不为了 Stage Gate 重写 WF-02 / WF-05。

---

## 2.2 `kangise/ecommerce-ai-skills` — 最值得吸收“知识/契约/运行时”四层

项目把同一套体系拆为：

```text
Knowledge
Ontology
Skills + Prompts
Runtime
```

并强调：真实店铺数据进入持久 Evidence；多个 Agent 做审查；写操作走 proposal → approval → execute；Worker 支持恢复；结论必须带来源；数据不完整直接报错，不用推测结果。

### 对 CrossPilot 的价值

#### A. Ontology 不应只是文档，而应成为共享 Contract
CrossPilot 已有 Adapter / Tool / Action 抽象，后续可以逐步形成：

```text
Entity: Store / Channel / Product / SKU / Campaign / Keyword / Order / Evidence / Action
Relation: Store-has-SKU / Campaign-targets-ASIN / Evidence-supports-Recommendation
Constraint: channel-specific limits / data freshness / write permissions
```

这不是让你现在新建“大而全知识图谱”，而是建议把散落在代码里的**跨平台硬约束与业务实体语义逐步集中**。

#### B. CI Gate 思路非常适合 Skill / Playbook
未来 Skill 不能只看“能跑”，还要在发布前检查：
- 是否定义输入和输出。
- 是否写失败边界。
- 是否声明 Evidence 要求。
- 是否定义禁止自动写动作。
- 是否有测试 / eval。
- 引用的规则是否过期。

#### C. Approval 不要暴露成 Agent Tool
Agent 可以查看 proposal，但审批本身应由 Host/UI 完成。否则“AI 自己调用 approve”会把 HITL 变成形式主义。

---

## 2.3 `anthropics/commerce-agents` — 对 CrossPilot 最重要的代码级参考

这个项目最值得看的不是模型，而是**安全约束放在哪里执行**。

它将规则分成两类：

```text
Prompt-level rule
→ 模型最好遵守

Executor/Gate-level rule
→ 模型不遵守也无法越过
```

### 最值得吸收的 8 个模式

1. **Provenance Gate**：写操作只能引用本 session 的读取工具实际返回过的 ID。
2. **Staged Write**：Agent 只生成 staged change，真正 apply 是另一条 Host approval 路径。
3. **Apply 时重新检查 Guardrail**：不是“审批时合法就永远合法”。如果配置在审批后收紧，apply 时仍应阻断。
4. **Host Approval 与聊天文本分离**：聊天里说“我批准”不能直接写成 `isApproved=true`；审批必须产生可信的系统记录。
5. **Tool Surface Allowlist**：部署配置决定 Agent 能看到什么 Tool，Executor 拒绝列表之外的调用。
6. **Credential 不进入模型**：凭证由 Host/Session 绑定，Tool 参数不携带 userId / merchantId / token。
7. **Missing value 返回 `None`，绝不返回替代 0**。
8. **有序流程在 Backend/Executor 强制**，而不是只靠模型“记得先 A 再 B”。

### 这直接验证了 Kimi 的三个修复优先级

- `ActionRouter.isApproved=true` 必须改。
- `xydc.mapper` 假默认数值必须改。
- ToolExecutionResult 应补 provenance/evidence 元数据。

---

## 2.4 `Shopify/claude-for-commerce-examples` — 最值得吸收 Staging 与 Mock/Real 同构

Shopify 示例把写路径拆得非常清楚：

```text
Agent stage_* tool
    ↓
Ledger entry
    ↓
Operator approval
    ↓
Host apply route
    ↓
Writer / Admin API mutation
```

真正修改店铺的 module 明确与上层 Agent 隔离，而且 apply 前重新检查 guardrail。

### 对 CrossPilot 更重要的是 Local Store 思路

Shopify 示例提供一个**无真实 Shopify 店铺也能跑完整审批链**的 local stand-in：

```text
Real Store: AdminGraphQLClient
Mock Store: LocalStore

下面这些完全不变：
Backend
Cache
Ledger
Gate
Router
Portal
Approval Path
```

这是 CrossPilot 模拟店铺项目最应该吸收的原则：

> **Mock 不应该模拟另一套系统；Mock 只替换 Adapter 末端，业务层、审批层、Evidence、Action、Workflow 必须和真实店完全共用。**

进一步建议：
- Mock 数据用固定 seed，确保回归可复现。
- Mock 必须有历史期数据，才能测试 WoW / 趋势 / 异常。
- Mock 可以有退款、断货、广告异常等预置故事线。
- 不能模拟的真实平台能力明确为空/unsupported，而不是伪造“看起来像真的”数据。

---

## 2.5 `KuudoAI/amazon_ads_mcp` — Tool / Skill / Knowledge / Data 四层分离

Kuudo 明确区分：

```text
MCP Tools = 原子 API 能力
Skills = 多步、版本化 SOP
Agent Atlas = 带引用的运营知识
Agent Flow = 用户自己的真实数据
```

### 这是 CrossPilot Tool Platform 最值得吸收的结构

你目前已有 Tool Registry + Workflow/Playbook + Adapter，下一步不要让 Skill 直接包 API 细节：

```text
Adapter Tool = 原子能力
Playbook/Skill = 业务 SOP
Knowledge = 规则/方法论/平台政策
Evidence Store = 本次实际数据
```

### 另一个很值钱的点：Error Surface = Documentation Surface

当 Tool 调用失败时，不能只返回：

```json
{"error":"400 Bad Request"}
```

应该返回能让 Agent 下一次调用变正确的 Error Envelope：

```json
{
  "code": "INVALID_REPORT_FIELD",
  "message": "field 'organicSearchShare' is not valid for this report type",
  "why": "this report uses v3 metric names",
  "retryable": true,
  "suggested_fix": {
    "replace_field": "searchTermImpressionShare"
  },
  "docs_ref": "amazon_ads.report.sp_search_terms.v3"
}
```

这样可以显著减少 Agent “错一次 → 猜一次 → 再错”的无意义 Tool Call。

---

## 2.6 `zach22-1999/amazon-skills` — 把卖家 SOP 做成真正可工程化 Skill

最重要的不是某个具体选品 Skill，而是 `zach-seller-skill-creator` 的工程方法：

```text
业务问题硬门禁
→ 意图澄清
→ 调研补齐
→ 写 Skill
→ 写 Eval Case
→ With-skill vs Baseline
→ Assertions / Grading
→ Benchmark
→ 用户反馈
→ 迭代
```

### CrossPilot 应吸收成 Skill Factory

今后一个新业务 Skill 至少回答：

1. 业务目标是什么？
2. 现在人工怎么做？
3. SOP 步骤是什么？
4. 判断规则 / 阈值 / 例外是什么？
5. 什么情况下触发？
6. 输出什么才算完成？

然后必须有：
- 2~5 个真实 Case。
- 基线（无 Skill 或旧版 Skill）。
- 可客观验证的 assertion。
- pass rate / token / latency。
- 失败 Case 的 transcript 复盘。

这比“写一个很长的 Prompt 就叫 Skill”成熟得多。

---

## 2.7 `DannylydST/sorftime-seller-agent` — 独立 Review、风险只做信号、闭环持久化

值得吸收：

- 精确指令直接执行，探索性任务再走 Methodology / Workflow，避免所有问题都强行进入大流程。
- 风险标记可以是 advisory，而不是所有风险都硬阻断。
- 关键选品决策增加**独立复核**：规则检查 + fresh-context review / red team。
- 端到端选品流程的中间数据全部持久化，支持后续监控，而不是只留下最终报告。

### 对 CrossPilot 的落点

不要把所有 Risk 都做成一个 `BLOCK`：

```text
Policy Risk     → hard block
Capital Risk    → approval required
Operational Risk→ warning / observe
Data Quality    → degrade / hold
```

但注意：这只适合**业务风险提示**。对于权限、审批、数据隔离这类系统安全边界，必须硬阻断，不能 advisory。

---

## 2.8 `real-world-agents/cross-border-e-commerce` — Research Playbook 的 Evidence 标准

这个项目最值得吸收三点：

1. 一个趋势结论需要多个独立数据源互相佐证。
2. 非英语市场优先用当地语言做 Search / Keyword Research。
3. 最终报告显式列 `Data Gaps`，告诉用户哪些结论薄、哪些数据源没拿到。

### 建议 CrossPilot Market Research 统一输出

```text
Conclusion
Evidence Set
Corroboration Count
Source Freshness
Proxy Used?
Data Gaps
Confidence
Next Verification
```

这比只输出一个“confidence=0.82”更可解释。

---

## 2.9 `JuneYaooo/launchfit-ai` — 合规 Gate 思想值得吸收，但不要复制 Skill

它最有价值的是：

```text
severity
+ evidence
+ source
+ impact
+ required_action
+ needs_external_verification
```

以及：缺范围、缺材料、材料过期、授权不覆盖、官方来源冲突时，不能硬给 PASS。

### 适合 CrossPilot
未来 Product Launch / Compliance Stage 可采用：

```text
VERIFIED
NEEDS_EXTERNAL_VERIFICATION
MISSING_DOCUMENT
CONFLICTING_EVIDENCE
EXPIRED_EVIDENCE
MANUAL_REVIEW_REQUIRED
BLOCKED
```

### 注意
该项目许可证为 PolyForm Noncommercial，若 CrossPilot 有商业用途，不建议直接复制其 Skill/代码。本方案只吸收公开设计思想。

---

## 2.10 `zach22-1999/seller-second-brain` — Skill/MCP 之外要有 Decision Memory

它提出一个非常重要的区分：

```text
Skill / MCP = 怎么做
Decision Memory = 为什么当时这么做
```

如果 CrossPilot 长期运营店铺，真正有价值的 Memory 不是保存聊天摘要，而是保存：

```text
Decision
Evidence at the time
Alternatives considered
Reason
Owner
Outcome after 7/30/90 days
What we learned
```

例如：

```text
2026-09-01：没有暂停 keyword X
原因：点击只有 8，证据不足
7 天后：CVR 恢复到 11%
结论：低样本 0-order 不应直接暂停
```

这会让未来 Agent 真正拥有“公司的运营经验”。

当前建议：P2。先把 Evidence / Action / Store Scope 做稳，再建设 Decision Memory。

---

# 3. Starsky 六点重新融合后的最终判断

## 3.1 Stage Gate

### Starsky
把 S1-S5 做成硬阶段，Stage 有 Entry / Evidence / Exit / Gate / Hold。

### CrossPilot 当前
没有独立 Stage 表，但 Workflow-first 已存在，WF-02/WF-05 也是确定性 SOP。

### 外部项目补充
- Zach Skill Creator 的“6 问硬门禁”证明业务 Gate 对复杂 SOP 有价值。
- real-world-agents 使用 defined research playbook，而不是即兴规划。
- LaunchFit 缺材料/冲突材料时 HOLD。
- Anthropic 则把固定顺序放 Backend 强制。

### 最终建议
**P2：先设计接口，不马上实现完整 Stage 系统。**

触发条件满足任一条再上：
- 真正出现 `Product Discovery → Validation → Supplier → Listing → Launch` 多阶段产品生命周期。
- 同一业务跨 3 个以上 Workflow。
- 需要人工在阶段之间正式签字。
- Stage 之间存在不同的 Evidence 要求和权限。

未来实现：

```text
StageInstance
StageGateEvaluator
StageTransitionService
```

叠加在 Workflow 上，不修改 DAG 内核。

---

## 3.2 Evidence Contract

### Starsky
缺数据不补数，低样本不强结论。

### CrossPilot 当前
已经有 Fact → Evidence → Recommendation 和 Gate，但四套模型并存，Tool 层 Evidence 元数据不统一，并存在假默认值。

### 外部项目补充
- Anthropic：没有数据返回 `None`，不是 0。
- Kangise：真实 CSV/API 导入后变持久 Evidence；结论必须带来源。
- real-world-agents：每次输出 Data Gaps；多源佐证。
- LaunchFit：实时政策标 `needs_external_verification`。

### 最终建议
这是**当前最值得增强的公共层之一**。

#### P0
修 `xydc.mapper.ts` 假默认值。

#### P1
统一 Tool Evidence Envelope：

```ts
interface EvidenceEnvelope<T> {
  value: T | null;
  status: 'KNOWN' | 'DERIVED' | 'ESTIMATED' | 'MISSING' | 'STALE' | 'CONFLICTING';
  sourceType: 'API' | 'FILE' | 'WEB' | 'USER' | 'SIMULATOR' | 'DERIVED';
  sourceRef?: string;
  observedAt?: string;
  freshness?: 'FRESH' | 'AGING' | 'STALE' | 'UNKNOWN';
  confidence?: number;
  proxy?: boolean;
  missingReason?: string;
}
```

不是要求每一个基础 DTO 都套这个壳，而是在**Tool Result / Evidence ingestion boundary**统一。

---

## 3.3 Human Approval

### Starsky
高风险 Action 先审核再导出/执行。

### CrossPilot 当前
总体比 Starsky 更强，但 `ActionRouter.isApproved` 裸布尔使防线出现单点破窗。

### 外部项目补充
Anthropic / Shopify 给出了最值得照着检查的原则：

```text
Agent 不能自己产生 Approval
Stage 与 Apply 分离
Apply 时重新检查权限与 Guardrail
Approval 必须对应具体 Payload
```

### 最终建议
**P0。**

建议 `dispatch()` 至少需要：

```ts
interface ApprovalProof {
  approvalId: string;
  actionId: string;
  payloadHash: string;
  approvedBy: string;
  approvedAt: string;
  expiresAt: string;
}
```

Executor 自己查库验证，不信调用方传来的 `isApproved: true`。

进一步要求：
- apply 前重新 assessRisk。
- payloadHash 必须匹配当前 action payload。
- 过期拒绝。
- 已使用 approval 不允许重复消费，除非 Action 定义允许幂等重试。

---

## 3.4 Product / Store Workspace

### Starsky
产品项目和店铺运营分开。

### CrossPilot 当前
现在最紧迫的问题不是“建两个漂亮 Workspace”，而是运营事实缺 `storeId`。

### 最终建议

#### P0/P1：先修真正的数据归因
至少逐步给：
- Order
- Campaign
- ProfitDaily
- InventoryBalance
- ChannelDailyMetric
- SKU unique key

增加：

```text
workspaceId + channelId + storeId (+ sellerSku / asin)
```

优先 Order + ProfitDaily，再扩其他表。

#### P2：再做 Product / Store Workspace 生命周期分层
当多店、多产品研究项目、长期运营同时上线后再拆。

---

## 3.5 Workflow-first

### Starsky
固定 SOP + 局部 Agent。

### CrossPilot 当前
已经正确，而且没有自由 LLM Planner。

### 外部项目补充
- Kuudo：Tool 是原子能力，Skill 是多步 SOP。
- Anthropic：固定顺序在 Backend 强制。
- Zach：SOP 可以经过 Eval 后变成版本化 Skill。
- Sorftime：明确指令直接做；模糊探索任务才进入完整方法论。

### 最终建议
**继续 Workflow-first，不引入自由 Planner。**

P1 做两件事：

1. `playbook-engine.ts` 不再只认两个硬编码 kind，把 WF-02/WF-05 收编为可注册执行器。
2. 增加确定性 UseCaseRouter：

```ts
const routes = {
  LISTING_OPTIMIZATION: 'wf02-listing',
  DAILY_OPERATION: 'wf05-daily-operation',
  AD_DIAGNOSIS: 'ads-diagnosis-playbook',
  PRODUCT_RESEARCH: 'product-research-playbook',
}
```

不要先上 LLM Intent Classifier；只有 use case 多到规则难维护时再考虑。

---

## 3.6 Stage Handoff / Resume

### Starsky
显式阶段交接。

### CrossPilot 当前
没有 Conversation 依赖是优点；真正缺的是 mid-DAG 崩溃续跑。

### 外部项目补充
- Kangise worker 使用恢复 + 幂等租约。
- Shopify staged ledger 让失败后的状态清晰可恢复。
- Anthropic 建议平台写接口使用 idempotency key。

### 最终建议

#### P1：先完成 Mid-DAG Resume
每个 Step 应至少持久化：

```ts
interface StepExecution {
  runId: string;
  stepId: string;
  status: 'PENDING' | 'RUNNING' | 'SUCCEEDED' | 'FAILED' | 'BLOCKED';
  attempt: number;
  inputHash: string;
  idempotencyKey?: string;
  startedAt?: string;
  finishedAt?: string;
  outputRef?: string;
  errorCode?: string;
}
```

Resume：
- SUCCEEDED 不重复。
- RUNNING 崩溃任务判断 lease 是否过期。
- 可幂等 Step 从 currentStep 重跑。
- 写操作必须靠 idempotency key / action status 防重复。

#### P2：Handoff DTO
等第一个真正跨多个 Agent/Workflow 的产品链路出现再实现。

---

# 4. 开源项目带来的 7 个“新增吸收点”

这些不是 Starsky 六点里直接包含的，但对 CrossPilot 很有价值。

## 4.1 Mock Adapter 与 Real Adapter 必须同构 — P1

来源：Shopify local store。

**要求：**

```text
MockAmazonAdapter
RealAmazonAdapter
MockShopifyAdapter
RealShopifyAdapter
```

必须实现相同 Port/Interface。

业务层禁止：

```ts
if (isMock) { specialBusinessLogic() }
```

允许：

```ts
adapter.getOrders(...)
adapter.getInventory(...)
adapter.applyAction(...)
```

Mock 只改变数据源，不改变上层 Workflow / Risk / Evidence / Approval。

这对你“没有真实店也要每天模拟经营数据”的场景尤其重要。

---

## 4.2 Error Envelope：失败要教 Agent 下一步怎么修 — P1

来源：Kuudo Amazon Ads MCP。

建议 Tool 失败统一为：

```ts
interface ToolErrorEnvelope {
  code: string;
  message: string;
  category: 'VALIDATION' | 'AUTH' | 'RATE_LIMIT' | 'UPSTREAM' | 'CONFLICT' | 'UNSUPPORTED';
  retryable: boolean;
  why?: string;
  suggestedFix?: Record<string, unknown>;
  docsRef?: string;
  retryAfterMs?: number;
  safeFallback?: string;
}
```

目标不是“错误更漂亮”，而是减少无方向重试和 Token 浪费。

---

## 4.3 Risk Policy 配置化 + Bounded Automation — P1

来源：Starsky + Nexscope dynamic pricing + Anthropic guardrails。

Kimi 已建议把 low/medium/high if 链收敛到 per-actionType 配置。

建议模型：

```yaml
DECREASE_BID:
  level: L3
  requiresApproval: true
  maxPercentDelta: 20
  evidence:
    minFreshness: 24h
    required: [clicks, spend, orders]
  rollback: supported

READ_REPORT:
  level: L0
  requiresApproval: false
```

L0-L4 不是为了命名漂亮，而是把**权限决策从业务代码变成可审计 Policy**。

可参考语义：

```text
L0 READ
L1 RECOMMEND
L2 DRAFT / STAGE
L3 HUMAN-APPROVED WRITE
L4 BOUNDED AUTOMATION
```

L4 必须同时满足：
- 白名单 actionType。
- 小范围可逆。
- Hard bounds。
- Fresh evidence。
- Circuit breaker。
- Rollback。
- Audit log。

---

## 4.4 Shadow → Pilot → Automation 发布路径 — P1/P2

来源：Nexscope dynamic pricing。

任何自动化策略不要从“Recommendation”直接跳“Auto Execute”：

```text
Observe Only
→ Shadow Recommendation
→ Human-approved Pilot
→ Small Bounded Automation
→ Expand
```

每一步都定义：

```text
KEEP
REVISE
PAUSE
REVERT
```

这特别适合：广告 bid、budget、pricing、补货建议。

---

## 4.5 Skill Factory + Skill Eval — P1

来源：Zach seller-skill-creator。

CrossPilot 工具越来越多后，真正的瓶颈会变成“运营经验怎么持续进入系统”。

建议新建：

```text
skills/
  <skill>/
    SKILL.md
    manifest.yaml
    references/
    scripts/
    evals/
```

Skill PR/Release Gate：
- 有业务目标。
- 有人工基线。
- 有明确 SOP。
- 有判断规则和边界。
- 有输入输出 Contract。
- 有 2~5 个 eval case。
- 有 baseline。
- 有 assertions。
- 有 fail case。

可以把 Skill 看成“业务代码”，而不是 Prompt 文档。

---

## 4.6 Research Corroboration + Data Gaps — P1

来源：real-world-agents。

对于选品 / 市场研究：

```text
单一来源 ≠ 市场结论
```

建议 Evidence Planner 支持：
- minimum corroboration sources。
- local language query。
- proxy 标记。
- data gaps。

示例：

```json
{
  "claim": "韩国消费者对小容量便携咖啡器具需求增长",
  "evidence_refs": ["search-trend-1", "social-2", "marketplace-5"],
  "corroboration": 3,
  "proxy_used": false,
  "data_gaps": ["no structured Coupang unit sales"],
  "confidence": "MEDIUM"
}
```

---

## 4.7 Decision Memory — P2

来源：seller-second-brain。

未来 Store Ops 不应只保存每日数字，还要保存“决策为什么发生”。

建议未来新增 `DecisionRecord`：

```ts
interface DecisionRecord {
  decisionId: string;
  storeId: string;
  subjectType: string;
  subjectId: string;
  decision: string;
  evidenceRefs: string[];
  alternatives?: string[];
  rationale: string;
  actionId?: string;
  decidedBy: string;
  decidedAt: string;
  reviewAt?: string;
  outcome?: Record<string, unknown>;
  lesson?: string;
}
```

不要存“模型的思维过程”；只存业务可解释的决策事实、依据与结果。

---

# 5. 最终优先级：建议按这个顺序做

## P0 — 先修，不要等新功能

### P0-1 `resetWorld` 删除范围安全
当前问题：`simulator-store.ts` 对 `channelDailyMetric` 的删除只按 `workspaceId`，可能误删与模拟器共享 workspace 的真实店数据。

要求：
- 模拟数据必须有 `source=SIMULATOR` / namespace / simulatorStoreId 等明确边界。
- destructive operation 必须带 scope。
- 增加真实数据保护回归测试。

### P0-2 ActionRouter 审批防伪
当前问题：`operation-automation.service.ts` 的 dispatch 路径存在 `isApproved: true` 裸布尔。

要求：
- 改 `approvalId`。
- DB 验证 status / hash / expiry / actionId。
- Apply 前 re-check Risk / Guardrail。
- Approval 不能由 Agent Tool 自己创建并消费。

### P0-3 Evidence 假默认值
当前问题：`xydc.mapper.ts` 有 48500 / 30.5 / 4.42 / 1120 等 stand-in 默认值。

要求：
- 删除。
- 缺失返回 null + missing reason。
- 添加回归测试：Missing 不得变成 0 或“合理数字”。

---

## P1 — 下一轮架构增强

建议顺序：

1. **storeId 归因**：Order + ProfitDaily 先做，之后扩 Campaign / Inventory / DailyMetric / SKU key。
2. **Evidence Envelope**：先在 ToolExecutionResult 增加 optional provenance，不要求一次迁完所有业务 DTO。
3. **Risk Policy 配置化**：actionType → L0-L4 / approval / bounds / evidence requirements。
4. **mid-DAG Resume**：StepExecution + lease + idempotency。
5. **Playbook 收编 WF-02 / WF-05**。
6. **UseCaseRouter**：确定性 mapping，不上 LLM router。
7. **Tool Error Envelope**。
8. **Mock/Real Adapter parity tests**。
9. **Skill Factory + Eval Gate**。
10. **Research Data Gaps + corroboration schema**。

---

## P2 — 条件成熟再做

1. 完整 Stage Gate / StageInstance。
2. Product Workspace / Store Workspace 彻底生命周期拆分。
3. Stage Handoff DTO。
4. Decision Memory / Seller Brain。
5. L4 Bounded Automation 大面积开放。

---

# 6. 建议的目标架构

```text
                         ┌─────────────────────┐
                         │ User / Scheduler    │
                         └──────────┬──────────┘
                                    ↓
                         ┌─────────────────────┐
                         │ Deterministic       │
                         │ UseCaseRouter       │
                         └──────────┬──────────┘
                                    ↓
               ┌──────────────────────────────────┐
               │ Playbook / Workflow Registry     │
               │ WF-02 / WF-05 / future skills   │
               └───────────────┬──────────────────┘
                               ↓
                   ┌──────────────────────┐
                   │ Tool Registry        │
                   └──────────┬───────────┘
                              ↓
        ┌───────────────────────────────────────────┐
        │ Tool Result + Evidence / Error Envelope    │
        └───────────────────┬───────────────────────┘
                            ↓
                 ┌──────────────────────┐
                 │ Evidence Gate         │
                 └──────────┬───────────┘
                            ↓
          ┌─────────────────────────────────┐
          │ Recommendation / ActionCandidate │
          └────────────────┬────────────────┘
                           ↓
                  ┌───────────────────┐
                  │ Risk Policy       │
                  │ L0-L4 + bounds    │
                  └─────────┬─────────┘
                            ↓
          ┌────────────────────────────────┐
          │ Approval Ledger / Proof        │
          └───────────────┬────────────────┘
                          ↓
                   ┌──────────────┐
                   │ Executor      │
                   │ re-check      │
                   └──────┬───────┘
                          ↓
               ┌─────────────────────┐
               │ Commerce Adapter     │
               └──────┬──────────────┘
                      │
          ┌───────────┼──────────────┐
          ↓           ↓              ↓
       Amazon      Shopify       Mock Store

Cross-cutting:
- tenant/channel/store scope
- checkpoint / resume / idempotency
- audit / provenance
- policy / ontology
- skill eval / release gate
```

---

# 7. 几个关键 Contract 建议

## 7.1 Tool Result

```ts
type ToolExecutionResult<T> = {
  ok: boolean;
  data?: T;
  evidence?: EvidenceMeta[];
  error?: ToolErrorEnvelope;
  execution: {
    toolName: string;
    executionId: string;
    startedAt: string;
    finishedAt: string;
  };
};
```

## 7.2 Evidence Meta

```ts
type EvidenceMeta = {
  evidenceId: string;
  sourceType: 'API' | 'FILE' | 'WEB' | 'USER' | 'SIMULATOR' | 'DERIVED';
  sourceRef?: string;
  observedAt?: string;
  freshness?: 'FRESH' | 'AGING' | 'STALE' | 'UNKNOWN';
  status: 'KNOWN' | 'DERIVED' | 'ESTIMATED' | 'MISSING' | 'CONFLICTING';
  proxy?: boolean;
};
```

## 7.3 Action Candidate

```ts
type ActionCandidate = {
  actionId: string;
  actionType: string;
  storeId: string;
  channelId: string;
  target: Record<string, string>;
  before?: unknown;
  after?: unknown;
  reason: string;
  evidenceIds: string[];
  riskLevel: 'L0' | 'L1' | 'L2' | 'L3' | 'L4';
  status: 'PROPOSED' | 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED' | 'EXECUTING' | 'DONE' | 'FAILED';
};
```

## 7.4 Tool Error Envelope

```ts
type ToolErrorEnvelope = {
  code: string;
  category: 'VALIDATION' | 'AUTH' | 'RATE_LIMIT' | 'UPSTREAM' | 'CONFLICT' | 'UNSUPPORTED';
  message: string;
  why?: string;
  retryable: boolean;
  retryAfterMs?: number;
  suggestedFix?: Record<string, unknown>;
  docsRef?: string;
};
```

---

# 8. Skill / Playbook 的统一规范

未来建议明确三层：

```text
Tool
= 原子能力，尽量无业务判断

Playbook / Skill
= 可版本化业务 SOP

Workflow
= 真正运行的状态机 / DAG
```

一个 Skill 可以：
- 调多个 Tool。
- 使用已有 Workflow。
- 调业务规则。
- 产出 Artifact。

但 Skill 不应该：
- 直接越过 Action Framework 写平台。
- 自己保存密钥。
- 自己定义一套 Approval。
- 自己把 missing 变默认值。

### Skill Manifest 建议

```yaml
name: ads-search-term-diagnosis
version: 1.2.0
useCase: AD_SEARCH_TERM_DIAGNOSIS
inputs:
  - storeId
  - dateRange
requiredEvidence:
  - searchTermReport
risk:
  maxLevel: L2
outputs:
  - diagnosis_report
  - action_candidates
failureModes:
  - REPORT_MISSING
  - ATTRIBUTION_WINDOW_NOT_MATURE
  - SAMPLE_TOO_THIN
evals:
  suite: evals/core.json
```

---

# 9. 对 Mock Store / 模拟器的专项建议

这一项是从 Shopify 示例新增吸收出来的，而且和你当前项目非常匹配。

## 9.1 只 Mock Adapter，不 Mock 上层业务

错误做法：

```text
Mock 页面
→ Mock Service
→ Mock Workflow
→ Mock DB
```

正确做法：

```text
同一个 UI
同一个 Workflow
同一个 Risk
同一个 Approval
同一个 Action
同一个 Evidence
        ↓
Adapter interface
   ↙           ↘
Mock          Real
```

## 9.2 Seed 必须可复现

```text
store_seed = 20260914
```

同 seed 应产生相同订单、广告、库存故事，才能做回归。

## 9.3 建议预置 Scenario

- 正常增长店。
- 广告花费突然上升。
- 库存即将断货。
- 高退款 SKU。
- Listing CVR 突降。
- 新品冷启动。
- 多店铺同 SKU code 冲突测试。
- API 部分缺数。
- Ads attribution 未成熟。

每个 Scenario 都应该有 Gold Expected Finding，方便测试 Agent。

---

# 10. 不应该吸收 / 暂时不要做的东西

1. **不要引入一个自由 LLM Planner 来替换现有 Workflow-first。**
2. **不要为了“像 Starsky”去重命名成 S1-S5。**
3. **不要现在就上庞大的 Product/Store Workspace 重构。**先解决 storeId。
4. **不要现在就把所有业务流程 Stage 化。**等真实跨阶段产品流程出现。
5. **不要把 Approval 暴露给 Agent 当普通 Tool。**
6. **不要把第三方业务阈值直接写成 CrossPilot 真理。**阈值必须来源于用户配置、平台规则或真实数据。
7. **不要复制 LaunchFit 的代码/Skill 用于商业用途。**其许可证不是通用商业开源许可。
8. **不要因为 Sorftime 有 7-agent panel，就给每个决策都上多 Agent。**独立复核只给高价值、难逆转决策。
9. **不要创建第二套 Evidence/Approval/Checkpoint。**目标是收敛，不是堆模块。

---

# 11. 推荐实施批次

## Batch A：Safety Patch

目标：先消除现行真实风险。

- resetWorld scope fix。
- approvalId DB proof。
- 删除假默认 Evidence。
- 相关回归测试。

**验收：**
- simulator reset 永远不能删除 real source 数据。
- 伪造 `isApproved=true` 无法 dispatch。
- null upstream metric 永远不会变成数字。

---

## Batch B：Contract Convergence

- storeId attribution（Order + ProfitDaily）。
- ToolExecutionResult evidence metadata。
- Error Envelope。
- Action risk policy config。

**验收：**
- 一个 Recommendation 可以一路追到 Tool source。
- 一个 Action 可以说明为什么需要审批。
- 多店同 sellerSku 不互相覆盖。

---

## Batch C：Execution Reliability

- mid-DAG resume。
- StepExecution。
- lease / idempotency。
- apply re-check。

**验收：**
- 在每个 Step 人工 kill 进程后重启，任务能从正确位置恢复。
- 写操作不会重复执行。

---

## Batch D：Playbook / Skill Platform

- WF-02 / WF-05 注册到 Playbook Engine。
- UseCaseRouter。
- Skill Manifest。
- Skill Eval harness。
- Release Gate。

**验收：**
- 新 SOP 不需要改 Router if/else 主干即可注册。
- 同一 Skill 有 baseline 与回归分数。

---

## Batch E：Commerce OS 增强（条件触发）

- Product lifecycle Stage Gate。
- Workspace lifecycle。
- Handoff DTO。
- Decision Memory。
- L4 Bounded Automation。

---

# 12. 给本地 AI 的代码审核/实施提示词

## 12.1 第一轮：只审核，不改代码

```text
请完整读取 CrossPilot 当前代码，以现有冻结架构为前提，不允许重构 WF-02/WF-05、Risk、Action、Commerce Adapter 主干。

重点核验下面问题，并给出文件路径、行号、调用链和测试证据：

P0：
1. simulator reset 是否可能删除非 simulator 的 ChannelDailyMetric 或其他真实数据。
2. 所有 Action dispatch 路径是否都必须验证数据库中的 approvalId / payloadHash / expiry / actionId，是否仍存在 isApproved 裸布尔或其他绕过。
3. 所有 Adapter / Mapper 是否存在“缺失值 → 假默认数字 / 0”的行为。

P1：
4. Order、ProfitDaily、Campaign、InventoryBalance、ChannelDailyMetric、SKU 的 storeId / channelId 归因是否足够支持多店。
5. ToolExecutionResult 是否能携带 evidence/provenance/freshness/missing 信息。
6. Risk 是否能按 actionType 配置，而不是散落 if/else。
7. daily-operation mid-DAG 崩溃后能否从 currentStep 恢复，写操作是否幂等。
8. WF-02/WF-05 是否可以被 Playbook Engine 注册调用。
9. 是否已有明确 useCase → playbook/workflow 的确定性 Router。
10. Mock 与 Real Adapter 是否走完全相同的 Workflow/Risk/Approval/Action 路径。

输出：
- 事实表
- 真实 P0/P1/P2
- 不需要做的项
- 最小改动方案
- 每项验收测试

先不要修改代码。
```

## 12.2 第二轮：只做 P0

```text
基于上一轮审核，只实施确认存在的 P0。
要求：
- 最小 patch。
- 不改变公共业务行为，除非原行为不安全。
- 每个 bug 先补失败测试，再修代码。
- 给出 before/after 调用链。
- 所有 destructive query 必须证明 scope。
- 所有 approval 必须由可信持久记录证明。
- 所有 missing metrics 必须保持 missing。
完成后运行相关测试并给出结果。
```

## 12.3 第三轮：P1 增强

```text
只在 P0 全部通过后实施 P1。
按这个顺序：
storeId → Evidence metadata → Risk Policy → Resume → Playbook Registry → UseCaseRouter → Error Envelope → Mock/Real parity → Skill Eval。

每做一项都必须满足：
1. additive change 优先；
2. 老接口兼容；
3. 有 migration/rollback；
4. 有单测；
5. 不复制一套新的 Evidence/Approval/Checkpoint；
6. 不引入自由 LLM Planner。
```

---

# 13. 推荐参考仓库清单

| 项目 | 最值得看 | 许可证/使用注意 |
|---|---|---|
| `kangise/ecommerce-ai-skills` | Ontology、Evidence、CI Gate、Runtime、approval | CC0，适合参考/复用 |
| `anthropics/commerce-agents` | provenance gates、staged writes、host approval、backend contract | Apache-2.0 |
| `Shopify/claude-for-commerce-examples` | Shopify Adapter、staging、Local Store 同构 Mock | Apache-2.0 |
| `KuudoAI/amazon_ads_mcp` | Tool/Skill/Knowledge/Data 分层、error envelope | MIT |
| `zach22-1999/amazon-skills` | SOP→Skill、产品研究、需求验证、Skill Creator/Eval | 根仓 MIT；部分 Skill 自带 Apache-2.0 |
| `DannylydST/sorftime-seller-agent` | 多平台真实数据、闭环选品、独立复核、风险 advisory | MIT |
| `zach22-1999/lingxing-mcp` | 多店 ERP 只读接入、固定出口、团队凭证隔离 | 先核对仓库具体许可证再复制代码 |
| `real-world-agents/cross-border-e-commerce` | 多源佐证、local-language research、Data Gaps | 参考前核对具体 license |
| `nexscope-ai/eCommerce-Skills` | 业务 Skill Catalog、dynamic pricing guardrails | MIT |
| `JuneYaooo/launchfit-ai` | Compliance Gate、external verification、材料缺口 | PolyForm Noncommercial：不要直接用于商业代码 |
| `zach22-1999/seller-second-brain` | Decision Memory / 业务第二大脑 | 文档 CC BY-NC-SA；思想参考 |

---

# 14. 本方案最终建议

如果只看下一阶段 CrossPilot 的投入产出，我会这样排：

```text
第一优先：修安全与数据真实性
resetWorld / approval bypass / fake default

第二优先：建立统一契约
storeId / evidence / risk policy / tool error

第三优先：提高执行可靠性
resume / idempotency / apply re-check

第四优先：让业务 SOP 可持续进入系统
playbook registry / use-case router / skill factory / eval

第五优先：业务复杂度达到阈值后再升级 Commerce OS
stage gate / workspace lifecycle / handoff / decision memory / bounded autopilot
```

真正应该从这些项目共同吸收的核心，不是它们用了哪个 Agent Framework，而是：

> **把 AI 的自由度放在“理解、分析、提出候选”上，把事实、权限、流程顺序、写操作、数据隔离和恢复能力放在确定性系统里。**

这与 CrossPilot 当前已经冻结的设计方向是一致的，因此本轮应该做“收敛 + 补洞 + 工程化”，而不是重新设计一个 V11 大架构。
