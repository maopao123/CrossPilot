# CrossPilot Reference Skill Pack

这不是 CrossPilot 正式生产 Skill，而是一组给本地 AI / Codex / Claude Code 用的**审计与设计辅助 Skill**。

目标：帮助你在不破坏既有 Workflow / Risk / Action / Adapter 架构的情况下，持续检查 Evidence、Approval、Store Scope、Recovery、Adapter 和 Stage Gate。

## 包含

- `crosspilot-code-audit`：总审计入口。
- `crosspilot-evidence-auditor`：证据真实性、缺失值、来源、freshness。
- `crosspilot-action-safety-auditor`：写操作、审批、防伪、Risk、Apply re-check。
- `crosspilot-store-scope-auditor`：tenant/channel/store/simulator 数据隔离与 destructive operation。
- `crosspilot-workflow-recovery-auditor`：Checkpoint、mid-DAG resume、idempotency。
- `crosspilot-adapter-contract-auditor`：Mock/Real Adapter 同构、错误契约、凭证边界。
- `crosspilot-playbook-author`：把重复 SOP 变成 Playbook/Skill，并设计 Eval。
- `crosspilot-stage-gate-designer`：只有当真实多阶段产品流程出现时才使用。

`UPSTREAM_SKILLS.md` 列出值得直接安装的第三方 Skill / Repo 和许可证注意事项。本压缩包默认不复制那些第三方代码，避免版本漂移；需要时按链接安装原版。
