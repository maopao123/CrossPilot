---
name: crosspilot-action-safety-auditor
description: Audit all CrossPilot write paths and action execution for approval proof, payload integrity, risk policy, idempotency, re-check-at-apply, rollback, and direct-adapter bypasses. Use before enabling any write action or bounded automation.
---
# Action Safety Auditor

## Non-negotiable checks
- No caller-provided `isApproved=true` is trusted.
- Approval is a persisted proof tied to actionId + payloadHash + expiry.
- Apply re-checks current risk/guardrails.
- Agent cannot approve its own proposal through a normal tool.
- All writes pass through Action Framework.
- Adapter write methods are unreachable from Agent/Workflow except Executor.
- Retries are idempotent.

## Risk levels
L0 READ
L1 RECOMMEND
L2 DRAFT/STAGE
L3 HUMAN-APPROVED WRITE
L4 BOUNDED AUTOMATION

L4 additionally requires hard bounds, kill switch, fresh evidence, rollback and audit.
