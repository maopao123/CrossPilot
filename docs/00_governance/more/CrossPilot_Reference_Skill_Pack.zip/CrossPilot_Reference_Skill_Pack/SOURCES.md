# Research sources

- Starsky Amazon Codex Releases: https://github.com/wenjiany312-hub/starsky-amazon-codex-releases
- Ecommerce AI Skills: https://github.com/kangise/ecommerce-ai-skills
- Anthropic Commerce Agents: https://github.com/anthropics/commerce-agents
- Shopify Claude for Commerce Examples: https://github.com/Shopify/claude-for-commerce-examples
- Kuudo Amazon Ads MCP: https://github.com/KuudoAI/amazon_ads_mcp
- Zach Amazon Skills: https://github.com/zach22-1999/amazon-skills
- Sorftime Seller Agent: https://github.com/DannylydST/sorftime-seller-agent
- Lingxing MCP: https://github.com/zach22-1999/lingxing-mcp
- Cross-Border E-Commerce Analyst: https://github.com/real-world-agents/cross-border-e-commerce
- Nexscope E-Commerce Skills: https://github.com/nexscope-ai/eCommerce-Skills
- LaunchFit AI: https://github.com/JuneYaooo/launchfit-ai
- Seller Second Brain: https://github.com/zach22-1999/seller-second-brain

本包 `skills/crosspilot-*` 为针对 CrossPilot 重新整理的原创审计/设计模板，不是上述第三方 Skill 的逐字复制。
